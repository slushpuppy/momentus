<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://blog.mapillary.com/update/2015/08/26/traffic-sign-updates.html',
            'body' => array(
                '//div[contains(@class, "blog-post__content")]',
            ),
        ),
    ),
);
