<?php

namespace PicoFeed\Client;

/**
 * TimeoutException Exception.
 *
 * @author  Frederic Guillot
 */
class TimeoutException extends ClientException
{
}
