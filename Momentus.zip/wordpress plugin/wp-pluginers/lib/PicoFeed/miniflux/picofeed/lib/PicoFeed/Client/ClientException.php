<?php

namespace PicoFeed\Client;

use PicoFeed\PicoFeedException;

/**
 * ClientException Exception.
 *
 * @author  Frederic Guillot
 */
abstract class ClientException extends PicoFeedException
{
}
