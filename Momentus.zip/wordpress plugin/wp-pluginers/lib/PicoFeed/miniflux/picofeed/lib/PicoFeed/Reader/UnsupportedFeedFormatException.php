<?php

namespace PicoFeed\Reader;

/**
 * UnsupportedFeedFormatException Exception.
 *
 * @author  Frederic Guillot
 */
class UnsupportedFeedFormatException extends ReaderException
{
}
