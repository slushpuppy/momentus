<?php

namespace PicoFeed\Parser;

/**
 * RSS 0.92 Parser.
 *
 * @package PicoFeed\Parser
 * @author  Frederic Guillot
 */
class Rss92 extends Rss20
{
}
