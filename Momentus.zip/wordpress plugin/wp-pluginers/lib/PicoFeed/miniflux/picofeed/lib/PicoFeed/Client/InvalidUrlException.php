<?php

namespace PicoFeed\Client;

/**
 * InvalidUrlException Exception.
 *
 * @author  Frederic Guillot
 */
class InvalidUrlException extends ClientException
{
}
