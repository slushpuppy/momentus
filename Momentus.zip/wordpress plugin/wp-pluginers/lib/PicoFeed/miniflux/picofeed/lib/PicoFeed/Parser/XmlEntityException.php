<?php

namespace PicoFeed\Parser;

/**
 * XmlEntityException Exception.
 *
 * @package PicoFeed\Parser
 * @author  Bernhard Posselt
 */
class XmlEntityException extends MalformedXmlException
{
}
