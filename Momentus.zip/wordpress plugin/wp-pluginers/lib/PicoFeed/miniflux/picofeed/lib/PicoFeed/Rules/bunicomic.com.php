<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.bunicomic.com/comic/buni-623/',
            'body' => array(
                '//div[@class="comic-table"]',
            ),
            'strip' => array(
            ),
        ),
    ),
);
