<?php

namespace PicoFeed\Client;

/**
 * @author  Bernhard Posselt
 */
class UnauthorizedException extends ClientException
{
}
