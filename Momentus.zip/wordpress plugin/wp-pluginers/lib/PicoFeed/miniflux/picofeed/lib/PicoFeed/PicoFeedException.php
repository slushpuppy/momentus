<?php

namespace PicoFeed;

use Exception;

/**
 * PicoFeedException Exception.
 *
 * @author  Frederic Guillot
 */
abstract class PicoFeedException extends Exception
{
}
