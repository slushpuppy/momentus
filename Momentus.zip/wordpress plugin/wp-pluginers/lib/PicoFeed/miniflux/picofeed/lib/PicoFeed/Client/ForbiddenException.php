<?php

namespace PicoFeed\Client;

/**
 * @author  Bernhard Posselt
 */
class ForbiddenException extends ClientException
{
}
