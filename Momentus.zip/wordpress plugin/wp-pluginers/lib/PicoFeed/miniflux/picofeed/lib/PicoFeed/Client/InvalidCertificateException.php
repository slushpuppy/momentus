<?php

namespace PicoFeed\Client;

/**
 * InvalidCertificateException Exception.
 *
 * @author  Frederic Guillot
 */
class InvalidCertificateException extends ClientException
{
}
