<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.bizjournals.com/milwaukee/news/2015/09/30/bucks-will-hike-prices-on-best-seats-at-new-arena.html',
            'body' => array(
                '//figure/div/a/img',
                '//p[@class="content__segment"]',
            ),
        ),
    ),
);
