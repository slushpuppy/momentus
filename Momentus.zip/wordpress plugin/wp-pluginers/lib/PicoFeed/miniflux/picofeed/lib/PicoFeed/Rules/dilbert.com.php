<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'body' => array(
                '//img[@class="img-responsive img-comic"]',
            ),
            'test_url' => 'http://dilbert.com/strip/2016-01-28',
        ),
    ),
);
