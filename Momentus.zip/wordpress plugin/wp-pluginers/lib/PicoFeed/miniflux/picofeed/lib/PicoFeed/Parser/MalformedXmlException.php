<?php

namespace PicoFeed\Parser;

/**
 * MalformedXmlException Exception.
 *
 * @package PicoFeed\Parser
 * @author  Frederic Guillot
 */
class MalformedXmlException extends ParserException
{
}
