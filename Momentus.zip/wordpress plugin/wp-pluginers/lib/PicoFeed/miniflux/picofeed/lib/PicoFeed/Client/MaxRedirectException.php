<?php

namespace PicoFeed\Client;

/**
 * MaxRedirectException Exception.
 *
 * @author  Frederic Guillot
 */
class MaxRedirectException extends ClientException
{
}
