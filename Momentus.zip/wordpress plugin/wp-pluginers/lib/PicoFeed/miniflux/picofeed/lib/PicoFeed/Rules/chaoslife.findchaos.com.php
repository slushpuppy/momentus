<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://chaoslife.findchaos.com/pets-in-the-wild',
            'body' => array('//div[@id="comic"]'),
            'strip' => array(),
        ),
    ),
);
