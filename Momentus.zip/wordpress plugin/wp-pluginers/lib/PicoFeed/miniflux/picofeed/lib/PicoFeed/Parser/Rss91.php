<?php

namespace PicoFeed\Parser;

/**
 * RSS 0.91 Parser.
 *
 * @package PicoFeed\Parser
 * @author  Frederic Guillot
 */
class Rss91 extends Rss20
{
}
