<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.dailytech.com/Apples+First+Fixes+to+iOS+9+Land+w+iOS++901+Release/article37495.htm',
            'body' => array(
            '//div[@class="NewsBodyImage"]',
            '//span[@id="lblSummary"]',
            '//span[@id="lblBody"]',
            ),
        ),
    ),
);
