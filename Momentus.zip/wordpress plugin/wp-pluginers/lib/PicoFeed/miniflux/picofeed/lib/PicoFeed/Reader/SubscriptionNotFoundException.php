<?php

namespace PicoFeed\Reader;

/**
 * SubscriptionNotFoundException Exception.
 *
 * @author  Frederic Guillot
 */
class SubscriptionNotFoundException extends ReaderException
{
}
