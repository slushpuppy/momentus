<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://espn.go.com/nfl/story/_/id/13388208/jason-whitlock-chip-kelly-controversy',
            'body' => array(
            '//p',
            ),
         ),
    ),
);
