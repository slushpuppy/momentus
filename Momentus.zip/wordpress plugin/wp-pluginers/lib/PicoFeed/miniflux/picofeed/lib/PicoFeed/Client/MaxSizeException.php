<?php

namespace PicoFeed\Client;

/**
 * MaxSizeException Exception.
 *
 * @author  Frederic Guillot
 */
class MaxSizeException extends ClientException
{
}
