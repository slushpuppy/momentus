<?php
return array(
    'filter' => array(
        '%.*%' => array(
             '%-150x150%' => '',
        ),
    ),
);
