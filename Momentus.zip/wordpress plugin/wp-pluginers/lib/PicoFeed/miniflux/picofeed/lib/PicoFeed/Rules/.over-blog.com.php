<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://eliascarpe.over-blog.com/2015/12/re-upload-projets-d-avenir.html',
            'body' => array(
                '//div[contains(concat(" ", normalize-space(@class), " "), " ob-section ")]',
            ),
        )
    )
);
