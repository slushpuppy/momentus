export class IAppContext {



    getEditBtnHTML() {
        return '';
    }
}