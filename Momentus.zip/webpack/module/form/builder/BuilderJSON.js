export class BuilderJSON {
    /**
     *
     * @param {string} type
     */
    constructor(type) {
        this.type = type;
        this.data = null;
    }
}