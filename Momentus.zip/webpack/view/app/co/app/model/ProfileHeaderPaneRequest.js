/**
 * @property {int|null} profileHeaderPaneRequest
 */
export class ProfileHeaderPaneRequest {
    constructor() {
        this.profileHeaderPaneRequest = null;

    }
    static assign(obj) {
        Object.assign(obj,new ProfileHeaderPaneRequest());
    }

}