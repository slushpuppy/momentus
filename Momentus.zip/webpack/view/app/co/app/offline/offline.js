import {offlineIcon} from 'ui/assets/cloud-connection.inline.svg';


$('#content').html();