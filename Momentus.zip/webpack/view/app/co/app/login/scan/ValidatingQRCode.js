export class ValidatingQRCode {

}