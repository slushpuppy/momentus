import {AbstractView} from "module/SinglePageApp/AbstractView";

export class EmailView extends AbstractView {

}