export class LoginBodyRequest {
    constructor() {
        this.qrcode = null;
        this.email = null;
    }
}