export const _LoginPageType = {
    "SCAN":'scanResponse',
    "PINCODE":'pincodeResponse',
    "EMAIL": 'emailResponse',

};
Object.freeze(_LoginPageType);