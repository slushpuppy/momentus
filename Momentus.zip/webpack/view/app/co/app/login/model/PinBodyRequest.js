export class PinBodyRequest {
    constructor() {
        this.pinSession = null;
        this.pin = null;
    }
}