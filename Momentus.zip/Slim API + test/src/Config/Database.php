<?php


namespace Config;


class Database
{
    public const HOST_NAME='127.0.0.1';
    public const USER_NAME= 'root';
    public const PASS= '';
    public const PORT='3306';

    public const DB_NAME='jobmajestic';
}