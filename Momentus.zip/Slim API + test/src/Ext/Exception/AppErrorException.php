<?php


namespace Ext\Exception;

use Exception;


class AppErrorException extends Exception
{
}