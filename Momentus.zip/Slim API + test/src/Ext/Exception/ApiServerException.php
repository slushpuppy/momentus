<?php


namespace Ext\Exception;

use Exception;


class ApiServerException extends Exception
{
}