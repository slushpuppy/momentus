<?php


namespace api\V1\Login\Internal\Model;


use api\V1\Model\Response;

class ResponseRefreshToken extends Response
{
    /**
     * @var string
     */
    public $data;
}