<?php


namespace api\V1\Login\Internal\Model;


class RequestVerification extends \Lib\Core\Helper\Http\Request
{

}