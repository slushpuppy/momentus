<?php


namespace api\V1\Login\Internal\Model;


class RequestEmail extends \Lib\Core\Helper\Http\Request
{
    public $email;
}