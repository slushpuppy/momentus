<?php


namespace api\V1\Login\Internal\Model;


class VerificationChannel
{
    /**
     * @var string
     */
    public $channel;
}