<?php


namespace api\V1\Oauth\Model;


class RequestRefreshToken extends \Lib\Core\Helper\Http\Request
{
    public $refresh_token;
}