<?php
namespace Config;
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 29/7/2018
 * Time: 1:42 PM
 */
class Db {
    /**
     *
     */
    const HOST = '127.0.0.1';
    /**
     *
     */
    const NAME = 'rust.bike';
    /**
     *
     */
    const PORT = '3306';
    /**
     *
     */
    const USER = 'root';
    /**
     *
     */
    const PASS = '';
}