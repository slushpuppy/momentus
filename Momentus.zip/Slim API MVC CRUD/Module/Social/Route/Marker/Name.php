<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 4/4/2019
 * Time: 11:58 AM
 */

namespace Module\Social\Route\Marker;


class Name
{
    const START="start";
    const REST="rest_stop";
    const INTEREST="point_of_interest";
    const END="end";
}