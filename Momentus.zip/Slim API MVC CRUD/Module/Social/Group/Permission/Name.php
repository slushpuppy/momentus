<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 1/4/2019
 * Time: 9:54 PM
 */

namespace Module\Social\Group\Permission;


class Name
{
    const CREATE_RIDE="CREATE_RIDE";
    const JOIN_RIDE="JOIN_RIDE";
    const MODERATOR="MODERATOR";
    const OWNER="OWNER";
}