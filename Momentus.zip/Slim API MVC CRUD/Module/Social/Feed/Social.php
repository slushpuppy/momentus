<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 22/11/2018
 * Time: 9:39 PM
 */

namespace Module\Social\Feed;

class Social {
    const POST_LEN = 512;
    const TOPICS_PER_PAGE = 20;
}