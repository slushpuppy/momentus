<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 3/12/2018
 * Time: 8:27 PM
 */

namespace Module\Social\OAuth;


class Scope
{
    public const ALL='social';
}