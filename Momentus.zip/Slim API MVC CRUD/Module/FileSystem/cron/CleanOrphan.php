<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 23/3/2019
 * Time: 7:16 PM
 */

namespace Module\FileSystem\cron;


use Lib\Core\CronInterface;

class CleanOrphan implements CronInterface
{

    function execute()
    {
        // TODO: Implement execute() method.
    }
}