<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 23/9/2018
 * Time: 11:02 PM
 */

namespace Module\User\Profile;


class Avatar extends Core
{

}