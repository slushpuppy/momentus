<?php
/**
 * Created by PhpStorm.
 * Account: Luke
 * Date: 21/8/2018
 * Time: 7:17 PM
 */

namespace Module\OAuth\Handler;


interface IData
{

}