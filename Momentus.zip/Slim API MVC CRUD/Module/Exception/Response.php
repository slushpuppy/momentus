<?php


namespace Module\Exception;


class Response  extends \Exception
{

}