<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 31/7/2018
 * Time: 10:30 PM
 */

namespace Module\Exception;


class OAuth extends \Exception
{

}