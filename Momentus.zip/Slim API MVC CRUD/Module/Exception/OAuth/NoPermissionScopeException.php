<?php


namespace Module\Exception\OAuth;


class NotInScopePermissionException extends \Exception
{

}