<?php


namespace Module\Exception\OAuth;


class NotInScopeException extends \Exception
{

}