<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 9/8/2018
 * Time: 8:40 PM
 */

namespace Module\Exception\OAuth;


class AccessToken extends \Module\Exception\_Exception
{

}