<?php


namespace Module\Exception;


class InvalidPermission extends \Exception
{

}