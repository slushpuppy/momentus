<?php
opcache_reset();
?>
