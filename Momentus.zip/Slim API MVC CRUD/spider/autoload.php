<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 29/7/2018
 * Time: 5:31 PM
 */
require_once (__DIR__.'/../autoload.php');