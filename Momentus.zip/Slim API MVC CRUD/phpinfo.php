<?php
if ($_GET['pass'] == "erfwef34fiir8989d44jf3889f8fiifijfwijfwijfw")
phpinfo();