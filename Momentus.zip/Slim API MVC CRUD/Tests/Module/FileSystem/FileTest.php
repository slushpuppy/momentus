<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 20/11/2018
 * Time: 3:15 PM
 */

namespace Tests\Module\FileSystem;

use PHPUnit\Framework\TestCase;

class FileTest extends TestCase
{

    public function testCreateFromBlob()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testCreateFromDbRow()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testLoadWithClassHandlers()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testGenerateFilePath()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testCreateFromUploadedFile()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testSave()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testGenerateSavePath()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testGetUrl()
    {
        $this->expectNotToPerformAssertions();
    }

    public function testGetColumns()
    {
        $this->expectNotToPerformAssertions();
    }
}
