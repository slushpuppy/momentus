<?php


namespace Config;


class Redis
{
    /**
     * @var string Contains the root URL
     */
    public const HOST = "127.0.0.1";
    /**
     * @var string Contains title for the site
     */
    public const PORT = "6379";

    public const SECRET_ENCRYPT_KEY = 'ij|9n.aFY)DqQ"T>`hIU$P8Q\'"o>inUvF(-*GF/PnPJk8ccg|?2/WfTk-ISf]QiPC.)4duGn~x,v*u\'rXf/>P^Kb?0#"/W=3p*~?!Z<(O:?5NvUb>M!JA,?n3i!HPg';
}