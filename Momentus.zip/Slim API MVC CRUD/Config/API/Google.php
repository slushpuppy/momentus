<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 9/10/2018
 * Time: 1:02 AM
 */
class Google {
    const API_KEY = 'AIzaSyAi95qPoqwprv4cEnKx8mmXBJmHwZ_rtEs';
}