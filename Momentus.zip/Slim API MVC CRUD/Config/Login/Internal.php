<?php


namespace Config\Login;


class Internal
{
    const TOKEN_VALIDITY_SEC=1800;
    const TOKEN_SECRET_KEY = 'g.\Dd<D{YN9_5FZu!Dg95G+\,.?n0~eg#KNzW>24p;3U?817_%IG>REvJ75+iVr{k,bxDg=\v,7(R!YCPwSG#Re2*Zt8om(C3X#)R5XD_[xS:Qu8`~J[7a?JTk^L~\'';
}