<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 8/8/2018
 * Time: 1:17 AM
 */

namespace Config\OAuth;


class General
{
    const TOKEN_BYTE_LENGTH = 64;
    const TOKEN_LIFESPAN_SECS = 5184000; //60 days
    const JWT_SECRET_KEY = ',fmIwOcJ.z$n<sFR[/b!cp1eBp2\'OSq4jApiLB|o0yy|%!xp9~9,/o#8M|dFYu-';

}