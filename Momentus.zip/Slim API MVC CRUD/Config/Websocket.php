<?php


namespace Config;


class Websocket
{
    public const PUSH_SERVERS = [
        'https://ws-sv.rust.bike:443'
    ];
}