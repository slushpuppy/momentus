<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 31/7/2018
 * Time: 11:14 PM
 */

namespace Config;


class Log
{
    const PATH = '/www/log';
    const ERROR_FILE = '/error.log';
    const WARNING_FILE = '/warning.log';
    const GENERAL_FILE = '/general.log';
}