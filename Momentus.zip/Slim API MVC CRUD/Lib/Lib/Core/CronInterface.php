<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 23/3/2019
 * Time: 7:17 PM
 */

namespace Lib\Core;


interface CronInterface
{
    function execute();
}