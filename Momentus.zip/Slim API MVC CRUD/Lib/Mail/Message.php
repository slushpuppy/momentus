<?php


namespace Lib\Mail;


class Message
{
    /**
     * @var string
     */
    public $subject;
    /**
     * @var string
     */
    public $body;
    /**
     * @var string
     */
    public $altBody;
}