<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 29/11/2018
 * Time: 9:02 PM
 */

namespace Lib\Core;


interface InstallInterface
{
    function add();
    function remove();
}