<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 26/2/2019
 * Time: 1:14 AM
 */

namespace Lib\Core\Helper\Security;


class Common
{
    public static function symmetric_encrypt(string $string) {
        return $string;
    }
    public static function symmetric_decrypt(string $string) {
        return $string;
    }
}