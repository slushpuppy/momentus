<?php
/**
 * Created by PhpStorm.
 * User: Luke
 * Date: 5/9/2018
 * Time: 4:24 PM
 */
namespace Lib\Core\Controller;

interface iAbstractController {
    /**
     * Init class functions
     * @return void
     */
    public static function init();
}